// Lottery ticket generator
// Author: Sahil Bora
// File: main.cpp

#include <cstdlib>
#include <iostream>
#include <ctime>
using namespace std;

// Constants
const int MIN  = 1;
const int MAX  = 45;
const int COLS = 6;
const int ROWS = 12;

// Function prototypes
void getLine(int line[]);
void printLine(int line[]);
bool duplicates(int num, int arr[], int size);

int main() {
    int row[COLS] = {0};
    srand(time(NULL));

    cout << "Your Tattslotto ticket\n\n";

    for (int i = 0; i < ROWS; i++) {
        getLine(row);
        printLine(row);
    }

    return 0;
}

// Check if a number already exists in the array
bool duplicates(int num, int arr[], int size) {
    for (int j = 0; j < size; j++) {
        if (arr[j] == num)
            return true;
    }
    return false;
}

// Generate a single lottery line with no duplicate numbers
void getLine(int line[]) {
    int rNum;
    for (int i = 0; i < COLS; i++) {
        rNum = rand() % (MAX - MIN + 1) + MIN;
        while (duplicates(rNum, line, i) == true)
            rNum = rand() % (MAX - MIN + 1) + MIN;
        line[i] = rNum;
    }
}

// Print a single lottery line
void printLine(int line[]) {
    for (int i = 0; i < COLS; i++)
        cout << "\n" << line[i];
    cout << endl << endl;
}