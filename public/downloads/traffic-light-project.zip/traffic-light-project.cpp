
#include "stdafx.h"
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <string.h>
#include <windows.h> // keep it here, just in case.
#include <cmath> // keep it here, just in case.

using namespace std; // Please do not remove this line

class OUSB 			// Do not change class name
{
	private:
		unsigned short PORTA;
		unsigned short PORTB;
		unsigned short PORTC;

	public:
		char command[256];

		OUSB();  // Remember to define this else it won't compile
		unsigned short readPORTA(unsigned short pinNumber);
		unsigned short readPORTB();
		unsigned short writePORTB(unsigned short newValue);
		unsigned short readPORTC();
		unsigned short runOUSBcommand(char* command);
};




// Traffic Light class
class TrafficLight // Do not change class name
{
	private:
		bool redLamp;
		bool yellowLamp;
		bool greenLamp;

	public: // Interface functions
		TrafficLight() {}; // Constructor

		void redOn();
		bool isREDon(); // Accessor function	

		void yellowOn();
		bool isYELLOWon(); // Accessor function

		void greenOn();
		bool isGREENon(); // Accessor function

		void changeTrafficLightState();
};



OUSB::OUSB()
{
	PORTA = 0;
	PORTB = 0;
	PORTC = 0;
}


unsigned short OUSB::runOUSBcommand(char* command)
{
	FILE *fpipe;
	char line[250] = {}; // size of Line should be smaller than command
			
	fpipe = (FILE*)_popen(command,"r");    // attempt to open pipe and execute a command    
	if( fpipe != NULL )					   // check that the pipe opened correctly
	{
		while( fgets(line, sizeof(line), fpipe) )
		{   // do nothing here, or print out debug data
			//cout << line; // print out OUSB data for debug purposes
		}
		_pclose(fpipe);   // close pipe
	}
	else cout << "Error, problems with pipe!\n";
		
	// do something with the value returned by the OUSB board, eg:
	int port = (int)atoi(line); // convert from char array to unsigned short
		
	return port;
}


unsigned short OUSB::readPORTA(unsigned short pinNumber)
{
	OUSB ousb;
	PORTA = ousb.runOUSBcommand("ousb -r io porta");
	return PORTA;
}

unsigned short OUSB::readPORTB()
{
	OUSB ousb;
	PORTB = ousb.runOUSBcommand("ousb -r io portb");
	return PORTB;
}


unsigned short OUSB::writePORTB(unsigned short newValue)
{
	OUSB ousb;
	PORTB = ousb.runOUSBcommand("ousb -r io portb %d");
	return PORTB;
}

unsigned short OUSB::readPORTC()
{
	OUSB ousb;
	PORTC = ousb.runOUSBcommand("ousb -r pin");
	return PORTC;
}


//-----------------------------------------------------
// Traffic Light
//-----------------------------------------------------
//Red
void TrafficLight::redOn()
{
	OUSB ousb;
	ousb.runOUSBcommand("ousb -r io portb 1");
	cout << "Red\n";
}

bool TrafficLight::isREDon()
{
	OUSB ousb;
	if(ousb.readPORTB() == 1)
		return true;
	else
		return false;
}


// Yellow
void TrafficLight::yellowOn()
{
	OUSB ousb;
	ousb.runOUSBcommand("ousb -r io portb 3");
	cout << "Yellow\n";
}

bool TrafficLight::isYELLOWon()
{
	OUSB ousb;
	if(ousb.readPORTB() == 3)
		return true;
	else
		return false;
}

// Green
void TrafficLight::greenOn()
{
	OUSB ousb;
	ousb.runOUSBcommand("ousb -r io portb 2");
	cout << "Green\n";
}

bool TrafficLight::isGREENon()
{
	OUSB ousb;
	if(ousb.readPORTB() == 2)
		return true;
	else
		return false;
}


// Change traffic state
void TrafficLight::changeTrafficLightState()
{
	OUSB ousb;
	switch(ousb.readPORTB())
	{
	case 1:
		greenOn();
		break;
	case 2:
		yellowOn();
		break;
	case 3:
		redOn();
		break;
	default:
		cout << "Error\n";
	}
}


int main(int argc, char *argv[])
{
	if (argc == 1) // no parameters print this line.
	{
		cout << "Traffic Light Program\n";
	}
	else if (argc == 3)
	{
		OUSB ousb;
		TrafficLight light;
		int num = atoi(argv[2]);
		
		if (num <= 50 && num >= 0)
		{
			if (argv[1][0] == 'R')
			{
				light.redOn();
			}
			else if (argv[1][0] == 'Y')
			{
				light.yellowOn();
			}
			else if (argv[1][0] == 'G')
			{
				light.greenOn();
			}
 
			// User input of the amount of cycles it will go through
			for (int i = 0; i < num; i++)
			{
				Sleep(500);
				light.changeTrafficLightState();
			}
		}
		else
			cout << "number out of range" << endl;
	}
	else
		cout << "wrong argument inputed" << endl;
	return 0;
}
