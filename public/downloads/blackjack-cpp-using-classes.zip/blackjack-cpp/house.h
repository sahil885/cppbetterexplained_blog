#ifndef HOUSE_H
#define HOUSE_H

#include "genericPlayerClass.h"

class House : public GenericPlayer {
public:
    House(const string& name = "House");
    virtual ~House();

    virtual bool IsHitting() const;
    void FlipFirstCard();
};

#endif
