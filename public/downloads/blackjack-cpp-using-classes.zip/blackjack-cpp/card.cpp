#include "card.h"

Card::Card(rank r, suit s, bool ifu): m_Rank(r), m_Suit(s), m_IsFaceUp(ifu) {}

int Card::GetValue() const {
    // If a card is face down, its value is 0
    int value = 0;
    if (m_IsFaceUp) {
        value = m_Rank;
        // Value is 10 for face cards
        if (value > 10) value = 10;
    }
    return value;
}

void Card::Flip() {
    m_IsFaceUp = !(m_IsFaceUp);
}
